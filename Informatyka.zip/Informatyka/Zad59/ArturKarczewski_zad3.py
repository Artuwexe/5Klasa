plik = open("liczby.txt")

#zad1
def CzyUnikalne(liczba):
    num = str(liczba)
    counter = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    for digit in num:
        if counter[int(digit)] == 1:
            return False
        counter[int(digit)] = 1
    return True
#zad2
def Palindromy10(liczba):
    liczbaStr = str(liczba)
    liczbaStrOd = liczbaStr[::-1]  # odwraca lancuch
    if liczbaStr == liczbaStrOd:
        return True
    else:
        return False

def PalindromyBinarne(liczba):
    liczbaBin = bin(liczba)[2:0]
    liczbaBinstr = str(liczbaBin)
    liczbaBinStrOd = liczbaBinstr[::-1]
    if liczbaBinstr == liczbaBinStrOd:
        return True
    else:
        return False

with open("liczby.txt") as plik:
    CounterDigit = 0
    CounterPalindrom = 0
    CounterBin = 0
    for linia in plik:
        number = int(linia)
        #print(number, CzyUnikalne(number))
        if CzyUnikalne(number) == True:
            CounterDigit +=1
        palind = int(linia)
        #print(palind, Palindromy10(palind))
        if Palindromy10(palind) == True:
            CounterPalindrom +=1
        palinBin = int(linia)
        if PalindromyBinarne(palinBin):
            CounterBin +=1
    print("Liczba unikalnych: ", CounterDigit)
    print("Liczba palindromów w systemie dziesiętnym", CounterPalindrom)
    print("liczba palindromów w systemie dziesiętnym", CounterBin)
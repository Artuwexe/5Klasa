plik = open("dane_obrazki.txt")

def czyRekurencyjne(obrazek):

    for i in range(10):
        linia1 = obrazek[i]
        linia2 = obrazek[i+10]
        if linia1[:10] != linia1[10:] or linia1[:10] != linia2[:10] or linia1[:10] != linia2[10:]:
            return False
    return True

zad2 = 0
obrazekRekurencyjny = list()
obrazek = list() #obrazek[][]
for linia in plik:
    obrazek.append(linia.strip()[:-1])
    if len(obrazek)==20:
        if czyRekurencyjne(obrazek):
            zad2+=1
            if(len(obrazekRekurencyjny) == 0):
                obrazekRekurencyjny = obrazek.copy()

    if len(obrazek) == 22:
        obrazek = list()

print(zad2)
for w in obrazekRekurencyjny:
    print(w)

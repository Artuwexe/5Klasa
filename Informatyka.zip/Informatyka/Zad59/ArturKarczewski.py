plik = open("liczby.txt")

def CzyUnikalna(liczba):
    liczbaStr = str(liczba)
    for znak1 in liczbaStr:
        for znak2 in liczbaStr:
            if(znak1==znak2):
                return True
    return False

zad = 0
for linia in plik:
    liczba = int(linia)
    if CzyUnikalna(liczba):
        zad+=1
print("Ilość liczb unikalnych:",zad)

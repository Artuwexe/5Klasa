plik = open("liczby.txt")
print("Zadanie drugie")
def czySumaPal(liczba):
    liczbaStr = str(liczba)
    liczbaStrOd = liczbaStr[::-1]  # odwraca lancuch
    liczbaOd = int(liczbaStrOd)
    suma = liczbaOd+liczba
    sumaStr = str(suma)
    print(liczba,liczbaOd,suma)
    if sumaStr == sumaStr[::-1]:
        print("TAK")
        return True
    else:
        print("NIE")
        return False

zad59_2 = 0
for linia in plik:
    liczba = int(linia)
    if czySumaPal(liczba):
        zad59_2+=1
print("ile suma palindromow",zad59_2)
plik = open("liczby.txt")
print("Zadanie trzecie")
def mocLiczby(liczba):
    liczbaStr = str(liczba)
    moc = 0
    while len(liczbaStr)>1:
        iloczyn = 1
        for znak in liczbaStr:
            iloczyn = iloczyn* int(znak)
        liczbaStr = str(iloczyn)
        moc+=1
    return moc
statystyka = dict()
for i in range(1,9):
    statystyka[i]=0

listaLiczbOMocy1 = list()
for linia in plik:
    liczba = int(linia)
    moc = mocLiczby(liczba)
    if moc==1:
        listaLiczbOMocy1.append(liczba)
    statystyka[moc]=statystyka[moc]+1

print(max(listaLiczbOMocy1),min(listaLiczbOMocy1))
print(statystyka)
plik = open("liczby.txt")

def czynniki(liczba):
    dzielnik = 3
    dzielniki = 0
    if liczba %2==0:
        return 0
    while dzielnik <= liczba:
        if liczba%dzielnik == 0:
            liczba = liczba/dzielnik
            if dzielnik%2!=0:
                dzielniki+=1
                if dzielniki > 3:
                    return False
            else:
                return False
        else:
            dzielnik+=2
    return dzielniki==3



zad1=0
for linia in plik:
    liczba = int(linia.strip())
    if czynniki(liczba)==3:
        zad1+=1
print("zad1=",zad1)
plik = open("dane_obrazki.txt")

def czy_poprawny(obrazek):
    for w in obrazek[:-1]:
        if w[:-1].count('1')%2 != int(w[-1]):
            return False

    for i in range(20):
        kolumna = ""
        for j in range(21):
            kolumna += obrazek[j][i]
        if kolumna[:-1].count('1')%2 != int(kolumna[-1]):
            return False

    return True
def czyNaprawialne(obrazek):
    bledneWiersz = 0
    for w in obrazek[:-1]:
        if w[:-1].count('1')%2 != int(w[-1]):
            bledneWiersz +=1
    if bledneWiersz > 1:
        return False
    bledneKolumna = 0
    for i in range(20):
        kolumna = ""
        for j in range(21):
            kolumna += obrazek[j][i]
        if kolumna[:-1].count('1')%2 != int(kolumna[-1]):
            bledneKolumna +=1
    if bledneKolumna >1:
        return False
    return True


poprawne = 0
naprawialne = 0
nieprawialne = 0;
obrazek = list() #obrazek[][]
for linia in plik:
    obrazek.append(linia.strip())
    if len(obrazek)==21:
       if(czy_poprawny(obrazek)):
           poprawne+=1
       else:
           if(czyNaprawialne(obrazek)):
               naprawialne+=1
           else:
                nieprawialne+=1

    if len(obrazek) == 22:
        obrazek = list()

print(poprawne)
print(naprawialne)
print(nieprawialne)
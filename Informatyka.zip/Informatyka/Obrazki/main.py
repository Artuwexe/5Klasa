
maxCzarne = []
plik = open("dane_obrazki.txt")
def obrazekRevers(obrazek):
    jedynek = 0
    for w in obrazek:
        jedynek += w.count('1')
        maxCzarne.append(jedynek)
    return jedynek > 200

zad1 = 0
obrazek = list() #obrazek[][]
for linia in plik:
    obrazek.append(linia.strip()[:-2])
    if len(obrazek)==20:
        if obrazekRevers(obrazek):
            zad1+=1
    if len(obrazek) == 22:
        obrazek = list()


print(zad1, max(maxCzarne))